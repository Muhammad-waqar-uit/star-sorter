#!/usr/bin/env node
// GitHub Stars organizer: auto-sorts your starred repos into GitHub Lists (the "folders" on your Stars page).
// Usage:  GITHUB_TOKEN=xxx node sort-stars.mjs plan     (dry run, writes plan.json)
//         GITHUB_TOKEN=xxx node sort-stars.mjs apply    (creates lists + adds repos)
// Flags:  --force  also re-sort repos that are already in a list
import fs from 'node:fs';

const TOKEN = process.env.GITHUB_TOKEN;
const cmd = process.argv[2] || 'plan';
const FORCE = process.argv.includes('--force');
if (!TOKEN) { console.error('Set GITHUB_TOKEN (classic token with the "user" scope).'); process.exit(1); }

const rules = JSON.parse(fs.readFileSync(new URL('./rules.json', import.meta.url)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function gql(query, variables = {}) {
  const res = await fetch('https://api.github.com/graphql', {
    method: 'POST',
    headers: { Authorization: `bearer ${TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  const json = await res.json();
  if (json.errors) throw new Error(JSON.stringify(json.errors));
  return json.data;
}

async function fetchStars() {
  const stars = [];
  let after = null;
  do {
    const d = await gql(
      `query($after:String){viewer{starredRepositories(first:100,after:$after,orderBy:{field:STARRED_AT,direction:DESC}){
        pageInfo{hasNextPage endCursor}
        nodes{id nameWithOwner description primaryLanguage{name} repositoryTopics(first:10){nodes{topic{name}}}}}}}`,
      { after }
    );
    const p = d.viewer.starredRepositories;
    for (const n of p.nodes) {
      stars.push({
        id: n.id,
        name: n.nameWithOwner,
        desc: n.description || '',
        lang: n.primaryLanguage?.name || '',
        topics: n.repositoryTopics.nodes.map((t) => t.topic.name),
      });
    }
    after = p.pageInfo.hasNextPage ? p.pageInfo.endCursor : null;
    process.stderr.write(`\rfetched ${stars.length} stars`);
  } while (after);
  process.stderr.write('\n');
  return stars;
}

async function fetchLists() {
  const d = await gql(`{viewer{lists(first:32){nodes{id name}}}}`);
  const lists = d.viewer.lists.nodes.map((l) => ({ ...l, repoIds: new Set() }));
  for (const l of lists) {
    let after = null;
    do {
      const r = await gql(
        `query($id:ID!,$after:String){node(id:$id){... on UserList{items(first:100,after:$after){pageInfo{hasNextPage endCursor} nodes{... on Repository{id}}}}}}`,
        { id: l.id, after }
      );
      const items = r.node.items;
      items.nodes.forEach((n) => n?.id && l.repoIds.add(n.id));
      after = items.pageInfo.hasNextPage ? items.pageInfo.endCursor : null;
    } while (after);
  }
  return lists;
}

function classify(repo) {
  const text = `${repo.name} ${repo.desc} ${repo.topics.join(' ')}`.toLowerCase();
  const hits = [];
  for (const rule of rules.lists) {
    const m = rule.match || {};
    const ok =
      (m.topics || []).some((t) => repo.topics.includes(t)) ||
      (m.languages || []).includes(repo.lang) ||
      (m.keywords || []).some((k) => text.includes(k.toLowerCase()));
    if (ok) hits.push(rule.name);
    if (hits.length >= (rules.maxListsPerRepo || 1)) break;
  }
  return hits;
}

async function main() {
  const [stars, lists] = await Promise.all([fetchStars(), fetchLists()]);
  const inAnyList = new Set(lists.flatMap((l) => [...l.repoIds]));
  const plan = [];
  const unmatched = [];
  for (const r of stars) {
    if (!FORCE && inAnyList.has(r.id)) continue;
    const target = classify(r);
    if (target.length) plan.push({ id: r.id, name: r.name, lists: target });
    else unmatched.push(r.name + (r.lang ? `  [${r.lang}]` : ''));
  }
  fs.writeFileSync('plan.json', JSON.stringify({ plan, unmatched }, null, 2));

  const counts = {};
  plan.forEach((p) => p.lists.forEach((l) => (counts[l] = (counts[l] || 0) + 1)));
  console.log('\nPlanned moves per list:');
  Object.entries(counts).sort((a, b) => b[1] - a[1]).forEach(([l, c]) => console.log(`  ${String(c).padStart(4)}  ${l}`));
  console.log(`\nUnmatched: ${unmatched.length} (see plan.json, add rules to rules.json)`);
  unmatched.slice(0, 25).forEach((u) => console.log('   -', u));

  if (cmd !== 'apply') return console.log('\nDry run only. Run with "apply" to make changes.');

  const byName = new Map(lists.map((l) => [l.name.toLowerCase(), l]));
  for (const name of Object.keys(counts)) {
    if (byName.has(name.toLowerCase())) continue;
    const rule = rules.lists.find((r) => r.name === name);
    const d = await gql(
      `mutation($i:CreateUserListInput!){createUserList(input:$i){list{id name}}}`,
      { i: { name, description: rule?.description || '', isPrivate: !!rules.private } }
    );
    const l = { ...d.createUserList.list, repoIds: new Set() };
    byName.set(name.toLowerCase(), l);
    lists.push(l);
    console.log(`created list: ${name}`);
  }

  let done = 0;
  for (const p of plan) {
    // updateUserListsForItem REPLACES the item's lists, so merge with existing memberships.
    const current = lists.filter((l) => l.repoIds.has(p.id)).map((l) => l.id);
    const wanted = p.lists.map((n) => byName.get(n.toLowerCase()).id);
    const listIds = [...new Set([...current, ...wanted])];
    await gql(
      `mutation($i:UpdateUserListsForItemInput!){updateUserListsForItem(input:$i){clientMutationId}}`,
      { i: { itemId: p.id, listIds } }
    );
    done++;
    process.stderr.write(`\rapplied ${done}/${plan.length}`);
    await sleep(250);
  }
  console.log('\nDone.');
}

main().catch((e) => { console.error('\nError:', e.message); process.exit(1); });
