# Star Sorter

Sorts your GitHub starred repos into GitHub Lists (the folders on your Stars page).

## Setup
1. Node 18+.
2. Create a **classic** personal access token at github.com/settings/tokens with the `user` scope.
3. `export GITHUB_TOKEN=ghp_xxx`

## Use
- `node sort-stars.mjs plan`   shows what would happen, writes plan.json (no changes made)
- `node sort-stars.mjs apply`  creates missing lists and adds repos
- `--force` also re-sorts repos already inside a list (default leaves them alone)

## Tune it
Edit `rules.json`. Each list matches on topics, primary language, or keywords found in the
repo name/description. First matching list wins (`maxListsPerRepo`: raise it to allow several).
Run `plan` again and check the "Unmatched" list to see which rules to add.
Note: GitHub allows at most 32 lists per account.
