# Star Sorter for GitHub (Chrome extension)

Install: chrome://extensions > turn on Developer mode > Load unpacked > pick this folder.

Use:
1. Create a classic token at github.com/settings/tokens with the `user` scope.
2. Open your Stars page (github.com/<you>?tab=stars). A green "Sort stars" button appears bottom right.
3. Paste the token, Save, then "Scan and preview".
4. Change any repo's target list with its dropdown, then "Apply".

"Edit rules" lets you change the lists and keywords (JSON). Max 32 lists per GitHub account.
The token is stored only in your browser (chrome.storage.local) and only sent to api.github.com.
