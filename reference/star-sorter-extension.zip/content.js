(() => {
  const store = {
    get: (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v[k]))),
    set: (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r)),
  };
  let rules = DEFAULT_RULES, token = '', plan = [], lists = [];
  const $ = (id) => document.getElementById(id);
  const log = (m) => ($('ss-log').textContent = m);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function gql(query, variables = {}) {
    const res = await fetch('https://api.github.com/graphql', {
      method: 'POST',
      headers: { Authorization: `bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables }),
    });
    const j = await res.json();
    if (j.errors) throw new Error(j.errors.map((e) => e.message).join('; '));
    return j.data;
  }

  async function fetchStars() {
    const out = []; let after = null;
    do {
      const d = await gql(`query($after:String){viewer{starredRepositories(first:100,after:$after,orderBy:{field:STARRED_AT,direction:DESC}){
        pageInfo{hasNextPage endCursor} nodes{id nameWithOwner description primaryLanguage{name} repositoryTopics(first:10){nodes{topic{name}}}}}}}`, { after });
      const p = d.viewer.starredRepositories;
      p.nodes.forEach((n) => out.push({ id: n.id, name: n.nameWithOwner, desc: n.description || '', lang: n.primaryLanguage?.name || '', topics: n.repositoryTopics.nodes.map((t) => t.topic.name) }));
      after = p.pageInfo.hasNextPage ? p.pageInfo.endCursor : null;
      log(`Fetched ${out.length} stars...`);
    } while (after);
    return out;
  }

  async function fetchLists() {
    const d = await gql(`{viewer{lists(first:32){nodes{id name}}}}`);
    const ls = d.viewer.lists.nodes.map((l) => ({ ...l, repoIds: new Set() }));
    for (const l of ls) {
      let after = null;
      do {
        const r = await gql(`query($id:ID!,$after:String){node(id:$id){... on UserList{items(first:100,after:$after){pageInfo{hasNextPage endCursor} nodes{... on Repository{id}}}}}}`, { id: l.id, after });
        r.node.items.nodes.forEach((n) => n?.id && l.repoIds.add(n.id));
        after = r.node.items.pageInfo.hasNextPage ? r.node.items.pageInfo.endCursor : null;
      } while (after);
    }
    return ls;
  }

  function classify(r) {
    const text = `${r.name} ${r.desc} ${r.topics.join(' ')}`.toLowerCase();
    const hits = [];
    for (const rule of rules.lists) {
      const m = rule.match || {};
      const ok = (m.topics || []).some((t) => r.topics.includes(t)) || (m.languages || []).includes(r.lang) || (m.keywords || []).some((k) => text.includes(k.toLowerCase()));
      if (ok) hits.push(rule.name);
      if (hits.length >= (rules.maxListsPerRepo || 1)) break;
    }
    return hits;
  }

  async function scan() {
    if (!token) return log('Paste a token and save it first.');
    $('ss-scan').disabled = true;
    try {
      const [stars, ls] = await Promise.all([fetchStars(), fetchLists()]);
      lists = ls;
      const inList = new Set(ls.flatMap((l) => [...l.repoIds]));
      const skipSorted = !$('ss-force').checked;
      plan = stars.filter((r) => !(skipSorted && inList.has(r.id))).map((r) => ({ id: r.id, name: r.name, target: classify(r)[0] || '' }));
      renderPlan();
    } catch (e) { log('Error: ' + e.message); }
    $('ss-scan').disabled = false;
  }

  function listNames() {
    const names = new Set([...rules.lists.map((l) => l.name), ...lists.map((l) => l.name)]);
    return [...names];
  }

  function renderPlan() {
    const box = $('ss-plan'); box.textContent = '';
    const names = listNames();
    plan.forEach((p, i) => {
      const row = document.createElement('div'); row.className = 'ss-row';
      const label = document.createElement('span'); label.textContent = p.name; label.title = p.name;
      const sel = document.createElement('select');
      [['', '(skip)'], ...names.map((n) => [n, n])].forEach(([v, t]) => { const o = document.createElement('option'); o.value = v; o.textContent = t; sel.appendChild(o); });
      sel.value = p.target;
      sel.onchange = () => { plan[i].target = sel.value; updateCount(); };
      row.append(label, sel); box.appendChild(row);
    });
    updateCount();
  }

  function updateCount() {
    const n = plan.filter((p) => p.target).length;
    $('ss-apply').textContent = `Apply ${n} moves`;
    $('ss-apply').disabled = n === 0;
    log(`${plan.length} repos shown, ${n} will be moved, ${plan.length - n} skipped. Change any dropdown before applying.`);
  }

  async function apply() {
    $('ss-apply').disabled = true;
    try {
      const todo = plan.filter((p) => p.target);
      const byName = new Map(lists.map((l) => [l.name.toLowerCase(), l]));
      for (const name of new Set(todo.map((p) => p.target))) {
        if (byName.has(name.toLowerCase())) continue;
        const rule = rules.lists.find((r) => r.name === name);
        const d = await gql(`mutation($i:CreateUserListInput!){createUserList(input:$i){list{id name}}}`, { i: { name, description: rule?.description || '', isPrivate: !!rules.private } });
        const l = { ...d.createUserList.list, repoIds: new Set() };
        byName.set(name.toLowerCase(), l); lists.push(l);
      }
      let n = 0;
      for (const p of todo) {
        const current = lists.filter((l) => l.repoIds.has(p.id)).map((l) => l.id);
        const target = byName.get(p.target.toLowerCase());
        const listIds = [...new Set([...current, target.id])];
        await gql(`mutation($i:UpdateUserListsForItemInput!){updateUserListsForItem(input:$i){clientMutationId}}`, { i: { itemId: p.id, listIds } });
        target.repoIds.add(p.id);
        log(`Applied ${++n}/${todo.length}`);
        await sleep(250);
      }
      log(`Done. ${n} repos sorted. Refresh the page to see your lists.`);
      plan = []; $('ss-plan').textContent = '';
    } catch (e) { log('Error: ' + e.message); $('ss-apply').disabled = false; }
  }

  function build() {
    const fab = document.createElement('button'); fab.id = 'ss-fab'; fab.textContent = '⭐ Sort stars';
    const panel = document.createElement('div'); panel.id = 'ss-panel';
    panel.innerHTML = `
      <h3>Star Sorter</h3>
      <input id="ss-token" type="password" placeholder="GitHub classic token (user scope)">
      <button id="ss-save">Save token</button>
      <button id="ss-rules-btn">Edit rules</button>
      <label><input type="checkbox" id="ss-force"> include repos already in a list</label>
      <div id="ss-rules-box" style="display:none">
        <textarea id="ss-rules"></textarea>
        <button id="ss-rules-save" class="primary">Save rules</button>
        <button id="ss-rules-reset">Reset to default</button>
      </div>
      <div><button id="ss-scan" class="primary">Scan and preview</button><button id="ss-apply" disabled>Apply</button></div>
      <div id="ss-log"></div><div id="ss-plan"></div>`;
    document.body.append(fab, panel);
    fab.onclick = () => panel.classList.toggle('open');
    $('ss-save').onclick = async () => { token = $('ss-token').value.trim(); await store.set('token', token); log('Token saved.'); };
    $('ss-rules-btn').onclick = () => { const b = $('ss-rules-box'); b.style.display = b.style.display === 'none' ? 'block' : 'none'; $('ss-rules').value = JSON.stringify(rules, null, 2); };
    $('ss-rules-save').onclick = async () => { try { rules = JSON.parse($('ss-rules').value); await store.set('rules', rules); log('Rules saved. Scan again.'); } catch (e) { log('Invalid JSON: ' + e.message); } };
    $('ss-rules-reset').onclick = async () => { rules = DEFAULT_RULES; await store.set('rules', rules); $('ss-rules').value = JSON.stringify(rules, null, 2); log('Rules reset.'); };
    $('ss-scan').onclick = scan;
    $('ss-apply').onclick = apply;
    const toggle = () => { const on = /[?&]tab=stars/.test(location.search) || location.pathname.startsWith('/stars'); fab.style.display = on ? '' : 'none'; if (!on) panel.classList.remove('open'); };
    toggle(); setInterval(toggle, 800);
  }

  (async () => {
    token = (await store.get('token')) || '';
    rules = (await store.get('rules')) || DEFAULT_RULES;
    build();
    if (token) $('ss-token').value = token;
  })();
})();
